package com.gr6.SmartCart.modules.catalog.service.impl;

import com.gr6.SmartCart.common.base.BaseResponse;
import com.gr6.SmartCart.common.base.PageResponse;
import com.gr6.SmartCart.common.domain.Category;
import com.gr6.SmartCart.common.domain.Product;
import com.gr6.SmartCart.common.domain.ProductVariant;
import com.gr6.SmartCart.common.domain.Shop;
import com.gr6.SmartCart.common.domain.User;
import com.gr6.SmartCart.common.enums.CategoryStatus;
import com.gr6.SmartCart.common.enums.OrderStatus;
import com.gr6.SmartCart.common.enums.ProductStatus;
import com.gr6.SmartCart.common.enums.ShopStatus;
import com.gr6.SmartCart.common.enums.VariantStatus;
import com.gr6.SmartCart.modules.catalog.dto.ProductRequest;
import com.gr6.SmartCart.modules.catalog.dto.ProductResponse;
import com.gr6.SmartCart.modules.catalog.repository.CatalogOrderItemRepository;
import com.gr6.SmartCart.modules.catalog.repository.CatalogReviewRepository;
import com.gr6.SmartCart.modules.catalog.repository.CategoryRepository;
import com.gr6.SmartCart.modules.catalog.repository.ProductRepository;
import com.gr6.SmartCart.modules.catalog.service.ProductService;
import com.gr6.SmartCart.modules.identity.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final UserRepository userRepository;
    private final CatalogReviewRepository catalogReviewRepository;
    private final CatalogOrderItemRepository catalogOrderItemRepository;

    @Override
    @Transactional
    public BaseResponse<ProductResponse> createProduct(ProductRequest request) {
        Shop currentShop = getCurrentActiveShop();
        if (currentShop == null) {
            return BaseResponse.error(403, "Shop chưa được duyệt hoặc tài khoản không phải seller");
        }

        Category category = getActiveCategory(request.getCategoryId());
        if (category == null) {
            return BaseResponse.error(400, "Danh mục không tồn tại hoặc đang bị ẩn");
        }

        Product product = new Product();
        product.setShop(currentShop);
        product.setCategory(category);
        product.setName(trim(request.getName()));
        product.setDescription(trim(request.getDescription()));
        product.setBrand(trim(request.getBrand()));
        product.setCondition(request.getCondition());
        product.setBasePrice(request.getBasePrice());
        product.setWeight(request.getWeight());
        product.setLength(request.getLength());
        product.setWidth(request.getWidth());
        product.setHeight(request.getHeight());
        product.setStatus(ProductStatus.ACTIVE);
        product.setImageUrls(joinImages(request.getUploadImages()));

        ProductVariant defaultVariant = new ProductVariant();
        defaultVariant.setProduct(product);
        defaultVariant.setSku("DEFAULT-" + System.currentTimeMillis());
        defaultVariant.setPrice(request.getBasePrice());
        defaultVariant.setStockQuantity(request.getStockQuantity() == null ? 0 : request.getStockQuantity());
        defaultVariant.setImageUrl(firstImage(request.getUploadImages()));
        defaultVariant.setStatus(VariantStatus.ACTIVE);

        List<ProductVariant> variants = new ArrayList<>();
        variants.add(defaultVariant);
        product.setVariants(variants);

        Product saved = productRepository.save(product);
        return BaseResponse.success_data("Thành công", enrichResponse(saved));
    }

    // THÊM THAM SỐ Long shopId ĐỂ KHỚP VỚI INTERFACE CŨ, NHƯNG BỎ QUA NÓ ĐỂ CHỐNG IDOR
    @Override
    @Transactional(readOnly = true)
    public BaseResponse<PageResponse<ProductResponse>> getProductsByShop(Long shopId, int page, int size) {
        Shop currentShop = getCurrentShopAllowInactive();
        if (currentShop == null) {
            return BaseResponse.error(403, "Không tìm thấy shop của seller hiện tại");
        }

        Pageable pageable = PageRequest.of(normalizePage(page), normalizeSize(size));
        Page<ProductResponse> result = productRepository
                .findByShopShopIdAndStatusNot(currentShop.getShopId(), ProductStatus.DELETED, pageable)
                .map(this::enrichResponse);

        return BaseResponse.success_data("Thành công", PageResponse.of(result));
    }

    @Override
    @Transactional(readOnly = true)
    public BaseResponse<ProductResponse> getProductForSeller(Long productId) {
        Shop currentShop = getCurrentShopAllowInactive();
        if (currentShop == null) {
            return BaseResponse.error(403, "Không tìm thấy shop của seller hiện tại");
        }

        Product product = productRepository
                .findByProductIdAndShopShopIdAndStatusNot(productId, currentShop.getShopId(), ProductStatus.DELETED)
                .orElse(null);

        if (product == null) {
            return BaseResponse.error(404, "Không tìm thấy sản phẩm thuộc shop của bạn");
        }

        return BaseResponse.success_data("Thành công", enrichResponse(product));
    }

    @Override
    @Transactional
    public BaseResponse<ProductResponse> updateProduct(Long productId, ProductRequest request) {
        Shop currentShop = getCurrentActiveShop();
        if (currentShop == null) {
            return BaseResponse.error(403, "Shop chưa được duyệt hoặc tài khoản không phải seller");
        }

        Product product = productRepository
                .findByProductIdAndShopShopIdAndStatusNot(productId, currentShop.getShopId(), ProductStatus.DELETED)
                .orElse(null);

        if (product == null) {
            return BaseResponse.error(404, "Không tìm thấy sản phẩm thuộc shop của bạn");
        }
        if (product.getStatus() == ProductStatus.BANNED) {
            return BaseResponse.error(403, "Sản phẩm đang bị admin khóa, seller không thể chỉnh sửa");
        }

        Category category = getActiveCategory(request.getCategoryId());
        if (category == null) {
            return BaseResponse.error(400, "Danh mục không tồn tại hoặc đang bị ẩn");
        }

        product.setCategory(category);
        product.setName(trim(request.getName()));
        product.setDescription(trim(request.getDescription()));
        product.setBrand(trim(request.getBrand()));
        product.setCondition(request.getCondition());
        product.setBasePrice(request.getBasePrice());
        product.setWeight(request.getWeight());
        product.setLength(request.getLength());
        product.setWidth(request.getWidth());
        product.setHeight(request.getHeight());
        product.setImageUrls(joinImages(request.getUploadImages()));

        syncDefaultVariant(product, request);

        Product saved = productRepository.save(product);
        return BaseResponse.success_data("Thành công", enrichResponse(saved));
    }

    @Override
    @Transactional
    public BaseResponse<String> deleteProduct(Long productId) {
        Shop currentShop = getCurrentShopAllowInactive();
        if (currentShop == null) {
            return BaseResponse.error(403, "Không tìm thấy shop của seller hiện tại");
        }

        Product product = productRepository
                .findByProductIdAndShopShopIdAndStatusNot(productId, currentShop.getShopId(), ProductStatus.DELETED)
                .orElse(null);

        if (product == null) {
            return BaseResponse.error(404, "Không tìm thấy sản phẩm thuộc shop của bạn");
        }
        if (product.getStatus() == ProductStatus.BANNED) {
            return BaseResponse.error(403, "Sản phẩm đang bị admin khóa, seller không thể xóa");
        }

        product.setStatus(ProductStatus.DELETED);
        if (product.getVariants() != null) {
            for (ProductVariant variant : product.getVariants()) {
                variant.setStatus(VariantStatus.DELETED);
            }
        }
        productRepository.save(product);

        return BaseResponse.successMessage("Đã xóa sản phẩm thành công");
    }

    private void syncDefaultVariant(Product product, ProductRequest request) {
        if (product.getVariants() == null) {
            product.setVariants(new ArrayList<>());
        }

        ProductVariant defaultVariant = product.getVariants().stream()
                .min(Comparator.comparing(ProductVariant::getVariantId, Comparator.nullsLast(Long::compareTo)))
                .orElse(null);

        if (defaultVariant == null) {
            defaultVariant = new ProductVariant();
            defaultVariant.setProduct(product);
            defaultVariant.setSku("DEFAULT-" + product.getProductId() + "-" + System.currentTimeMillis());
            defaultVariant.setStatus(VariantStatus.ACTIVE);
            product.getVariants().add(defaultVariant);
        }

        defaultVariant.setPrice(request.getBasePrice());
        defaultVariant.setStockQuantity(request.getStockQuantity() == null ? 0 : request.getStockQuantity());
        defaultVariant.setImageUrl(firstImage(request.getUploadImages()));
        if (defaultVariant.getStatus() == null || defaultVariant.getStatus() == VariantStatus.DELETED) {
            defaultVariant.setStatus(VariantStatus.ACTIVE);
        }
    }

    private ProductResponse enrichResponse(Product product) {
        ProductResponse response = ProductResponse.fromEntity(product);

        Integer sold = catalogOrderItemRepository.getSoldQuantityByProductId(product.getProductId(), OrderStatus.DELIVERED);
        response.setSoldQuantity(sold == null ? 0 : sold);

        Double averageRating = catalogReviewRepository.getAverageRatingByProductId(product.getProductId());
        response.setAverageRating(averageRating == null ? 0.0 : Math.round(averageRating * 10.0) / 10.0);

        return response;
    }

    private Shop getCurrentActiveShop() {
        Shop shop = getCurrentShopAllowInactive();
        if (shop == null || shop.getStatus() != ShopStatus.ACTIVE) {
            return null;
        }
        return shop;
    }

    private Shop getCurrentShopAllowInactive() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || authentication.getName() == null) {
            return null;
        }

        User user = userRepository.findByEmail(authentication.getName()).orElse(null);
        if (user == null || user.getShop() == null) {
            return null;
        }
        return user.getShop();
    }

    private Category getActiveCategory(Long categoryId) {
        if (categoryId == null) {
            return null;
        }

        Category category = categoryRepository.findById(categoryId).orElse(null);
        if (category == null || category.getCategoryStatus() != CategoryStatus.ACTIVE) {
            return null;
        }
        return category;
    }

    private String joinImages(List<String> images) {
        if (images == null) {
            return null;
        }
        String value = images.stream()
                .filter(img -> img != null && !img.trim().isEmpty())
                .map(String::trim)
                .collect(Collectors.joining(","));
        return value.isBlank() ? null : value;
    }

    private String firstImage(List<String> images) {
        if (images == null) {
            return null;
        }
        return images.stream()
                .filter(img -> img != null && !img.trim().isEmpty())
                .map(String::trim)
                .findFirst()
                .orElse(null);
    }

    private int normalizePage(int page) {
        return Math.max(page - 1, 0);
    }

    private int normalizeSize(int size) {
        if (size <= 0) return 10;
        return Math.min(size, 100);
    }

    private String trim(String value) {
        return value == null ? null : value.trim();
    }
}